package practiceproject;
public class proaccessSpecifiers1 extends proaccessspecifiers {

	public static void main(String[] args) {
		proaccessSpecifiers1 obj = new proaccessSpecifiers1 ();   
	       obj.display();  
	}

}
