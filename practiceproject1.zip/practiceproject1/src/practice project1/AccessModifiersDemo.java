package practiceproject;
//Define a class with different access modifiers
public class AccessModifiersDemo {

 // Public field
 public int publicField = 10;

 // Private field
 private int privateField = 20;

 // Protected field
 protected int protectedField = 30;

 // Default (package-private) field
 int defaultField = 40;

 // Constructor
 public AccessModifiersDemo() {
     System.out.println("AccessModifiersDemo constructor called.");
 }

 // Public method
 public void publicMethod() {
     System.out.println("This is a public method.");
 }

 // Private method
 private void privateMethod() {
     System.out.println("This is a private method.");
 }

 // Protected method
 protected void protectedMethod() {
     System.out.println("This is a protected method.");
 }

 // Default (package-private) method
 void defaultMethod() {
     System.out.println("This is a default method.");
 }

 // Main method to test access modifiers
 public static void main(String[] args) {
     AccessModifiersDemo demo = new AccessModifiersDemo();

     System.out.println("Accessing publicField: " + demo.publicField);
     // Accessing privateField will result in a compilation error
     // System.out.println("Accessing privateField: " + demo.privateField);
     System.out.println("Accessing protectedField: " + demo.protectedField);
     System.out.println("Accessing defaultField: " + demo.defaultField);

     demo.publicMethod();
     // Attempting to call privateMethod will result in a compilation error
     // demo.privateMethod();
     demo.protectedMethod();
     demo.defaultMethod();
 }
}
