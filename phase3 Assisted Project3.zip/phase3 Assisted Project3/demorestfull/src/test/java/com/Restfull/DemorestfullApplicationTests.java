package com.Restfull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemorestfullApplicationTests {

	@Test
	void contextLoads() {
	}

}
