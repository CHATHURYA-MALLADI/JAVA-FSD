package practiceproject1;
import java.io.*;

public class FileHandling {
    public static void main(String[] args) {
        String filePath = "example.txt";

        // Read from the file
        try {
            FileReader reader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;
            System.out.println("Reading from the file:");
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            bufferedReader.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }

        // Append to the file
        try {
            FileWriter writer = new FileWriter(filePath, true); // append mode
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            String newData = "\nAppending a new line.";
            bufferedWriter.write(newData);

            bufferedWriter.close();
            System.out.println("Successfully appended to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while appending to the file.");
            e.printStackTrace();
        }

        // Read the updated file
        try {
            FileReader reader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;
            System.out.println("Reading the updated file:");
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            bufferedReader.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading the updated file.");
            e.printStackTrace();
        }
    }
}


