package javax.persistence;

public class Column {

}
